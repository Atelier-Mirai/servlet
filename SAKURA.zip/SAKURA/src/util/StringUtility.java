package util;

public class StringUtility {
  // 文字列を指定された総文字数に指定された文字で右詰めする。。
  // str = StringUtility.pad(str, 10, "0");
  // System.out.println(str); // "0000000001" が出力

  // String.format("%010d", number) とほぼ同義
  public static String padding(String str, int totalLen, char chr) {
    // 文字列長チェック
    if (str.length() > totalLen) {
      return str;
    }

    var sb  = new StringBuffer();
    for (int i = str.length(); i < totalLen; i++) {
      sb.append(chr);
    }
    sb.append(str);
    return sb.toString();
  }

  public static String padding(int intStr, int totalLen, char chr) {
    return StringUtility.padding(String.valueOf(intStr), totalLen, chr);
  }

  public static Boolean isBlank(String str) {
    return str == null || str.strip().length() == 0;
  }

  public static Boolean isPresent(String str) {
    return !isBlank(str);
  }

  public static String prettify(int price) {
    return String.format("%,7d", price);
  }

  public static String capitalize(String str) {
    if (str == null || str.length() == 0) {
      return str;
    }
    return str.substring(0, 1).toUpperCase() + str.substring(1);
	}
}
