package goods;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.StringUtility;

// 商品検索を行うServlet
@WebServlet({"/goods/GoodsRefineSearchServlet"})
public class GoodsRefineSearchServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    req.setCharacterEncoding("UTF-8");
    GoodsDao dao  = null;
    String next   = null;
    String errmsg = null;

    // セッションの取得
    // ログインせずとも、普通は商品一覧できるよね。
    // HttpSession session = req.getSession(false);
    // if (session == null || session.getAttribute("cust") == null) {
    //   errmsg = "ログインを行ってください。";
    //   next   = "/system/error.jsp";
    //   req.setAttribute("errmsg", errmsg);
    //   req.getRequestDispatcher(next).forward(req, res);
    //   return;
    // }

    // ユーザ入力値取得
    String genre       = req.getParameter("genre");
    String name        = req.getParameter("name");
    String priceString = req.getParameter("price");

    // validation
    if (StringUtility.isPresent(genre) &&
          !(genre.equals("flower") ||
           genre.equals("liquor") ||
           genre.equals("food"))) {
      errmsg += "不正な商品分類です。<br>";
    }
    if (StringUtility.isPresent(name) && name.strip().length() >= 21) {
      errmsg += "商品名は20文字以下です。<br>";
    }
    int price = 0;
    if (StringUtility.isPresent(priceString)) {
      try {
        price = Integer.parseInt(priceString);
        if (price <= 0) {
          errmsg += "不正な金額です。<br>";
        } else if (price >= 1_000_000) {
          errmsg += "指定できる金額は999999までです。<br>";
        }
      } catch (NumberFormatException e1) {
        errmsg += "金額は整数です。";
      }
    }

    if (errmsg != null) {
      // 遷移先を指定、エラーメッセージを詰めて、遷移する。
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    try {
      var category = switch (genre) {
        case "flower" -> "花";
        case "liquor" -> "酒";
        case "food"   -> "食料品";
        default -> "";
      };

      // 確認
      System.out.printf("category: %s\n", category);
      System.out.printf("name: %s\n", name);
      System.out.printf("price: %s\n", price);

      dao = new GoodsDao();
      dao.connect();

      ArrayList<Goods> list = dao.queryByCondition(category, name, price==0 ? "" : String.valueOf(price));

      // if (list.isEmpty()) {
      //   errmsg = "検索条件に該当する商品はありませんでした。";
      //   req.setAttribute("errmsg", errmsg);
      //   next = "/system/error.jsp";
      // } else {
        req.setAttribute("list", list);
        next = "/goods/goods_list.jsp";
      // }
    } catch (ClassNotFoundException | SQLException e) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
        } catch (SQLException e) {}
      }
    }
    req.getRequestDispatcher(next).forward(req, res);
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doPost(req, res);
  }
}
