package goods;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import dao.Dao;
import util.StringUtility;

// GOODS(商品)テーブルにアクセス、データを永続化・復元する。
public class GoodsDao extends Dao {
  private String selectSql = """
                        SELECT goods_cd as cd,
                               goods_class as genre,
                               goods_name as name,
                               goods_notes as notes,
                               goods_picture_path as picture_path,
                               goods_price as price
                        FROM goods
                       """;

  // Goods テーブルを検索、商品データを ArrayList<Goods> として返す。
  // (該当無しなら、空のArrayListを返す。)
  public ArrayList<Goods> query() throws SQLException {
    return query(selectSql, "");
  }

  public ArrayList<Goods> query(String sql, String clause) throws SQLException {
    PreparedStatement stmt = null;
    ResultSet rs           = null;
    try {
      // 商品一覧を取得するSQL作成し、実行する
      stmt = con.prepareStatement(sql + clause + " ORDER BY goods_cd");
      rs   = stmt.executeQuery();

      // 商品格納用ホルダーの準備
      ArrayList<Goods> list = new ArrayList<>();
      while (rs.next()) {
        // 商品データ格納用のGoodsインスタンスを作成し、GoodsListに追加。
        list.add(new Goods(rs.getString("cd"),
                           rs.getString("genre"),
                           rs.getString("name"),
                           rs.getString("notes"),
                           rs.getString("picture_path"),
                           rs.getInt("price")
                          ));
      }
      // お持ち帰りする。
      return list;
    } catch (SQLException e) {
      throw e;
    } finally {
      try {
        if (rs   != null) { rs.close(); }
        if (stmt != null) { stmt.close(); }
      } catch (SQLException e) {}
    }
  }

  // CDを基に一件の商品データを取得
  public Goods findByGoodsCd(String cd) throws SQLException {
    var stmt = con.prepareStatement("WHERE goods_cd=?");
    stmt.setString(1, cd);
    var clause = stmt.toString();
    ArrayList<Goods> list = new ArrayList<>();
    list = query(selectSql, clause);
    if (list.isEmpty()) {
      // req.setAttribute("errmsg", "Item Not Found");
      return null;
    } else {
      // return list.getFirst(); // Java 21
      return list.get(0);
    }
  }

  // 商品検索 分類、商品名、価格によるWhere句を生成、商品リストを返す
  public ArrayList<Goods> queryByCondition(String... condition) throws SQLException {
    // condition = { class: "花",
    //                  name: "アレンジメント",
    //                  price: 5000 }
    // という、連想配列として扱いたい。

    // 引数: conditon
    //       => ["花", "アレンジメント", "5000"]
    // 作成したい where句:
    //           WHERE
    //           goods_class=?
    //           AND
    //           goods_name LIKE '%?%'
    //           AND
    //           goods_price<=?

    // Map型面倒なので、ArrayList 2個で代用
    ArrayList<String> clauseKeys   = new ArrayList<>();
    ArrayList<String> clauseValues = new ArrayList<>();

    // 可変長引数のそれぞれについて
    for (int i = 0; i < condition.length; i++){
      if (StringUtility.isPresent(condition[i])) {
        // キーリストに追加
        clauseKeys.add(
          switch(i) {
            case 0 -> "goods_class=?";
            case 1 -> "goods_name LIKE ?";
            case 2 -> "goods_price<=?";
            default -> "";
          }
        );
        // 値リストに追加
        clauseValues.add(condition[i]);
      }
    }

    // WHERE句の作成
    var clauseSql = "";
    if (!clauseKeys.isEmpty()) {
      // joinメソッドで連結
      clauseSql = String.join(" AND ", clauseKeys);
      // INパラメタを、キーに応じ、各値で置換する。
      var stmt  = con.prepareStatement(clauseSql);
      for(int i = 1; i <= clauseKeys.size(); i++) {
        var key   = clauseKeys.get(i-1);
        var value = clauseValues.get(i-1);
        switch(key) {
          case "goods_class=?"     -> stmt.setString(i, value);
          case "goods_name LIKE ?" -> stmt.setString(i, "%" + value + "%");
          case "goods_price<=?"    -> stmt.setInt(i,Integer.parseInt(value));
          default -> {}
        }
      }
      clauseSql = "WHERE " + stmt.toString();
    }
    // クエリ実行、商品一覧を返す。
    return query(selectSql, clauseSql);
  }
}
