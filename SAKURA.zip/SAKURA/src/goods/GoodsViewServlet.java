package goods;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import util.StringUtility;

// 商品情報を取得するServlet
@WebServlet({"/goods/GoodsViewServlet"})
public class GoodsViewServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doGet(req, res);
  }
  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    req.setCharacterEncoding("UTF-8");
    GoodsDao dao        = null;
    String next         = null;
    String errmsg       = null;
    HttpSession session = req.getSession(false);

    if (session == null || session.getAttribute("cust") == null) {
      errmsg = "ログインを行ってください。";
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    var goodsCd = req.getParameter("goodsCd");
    if (StringUtility.isBlank(goodsCd)) {
      errmsg = "商品コードの取得に失敗しました。";
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    // 正常系
    try {
      dao = new GoodsDao();
      dao.connect();
      Goods goods = dao.findByGoodsCd(goodsCd);
      // Goods goods = new Goods("0000000001", "花", "胡蝶蘭 1鉢", "胡蝶蘭をコンパクトサイズにしました。", "plant1.gif", 999_999);

      if (goods != null) {
        req.setAttribute("goods", goods);
        next = "/goods/goods_detail.jsp";
      } else {
        errmsg = "商品情報の取得に失敗しました。";
        next = "/system/error.jsp";
        req.setAttribute("errmsg", errmsg);
      }
    } catch (ClassNotFoundException | SQLException e) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
        } catch (SQLException e) {}
      }
    }
    // 画面遷移
    req.getRequestDispatcher(next).forward(req, res);
  }
}
