package goods;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// 商品一覧を取得するServlet
@WebServlet({"/goods/GoodsSearchServlet"})
public class GoodsSearchServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doGet(req, res);
  }
  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    GoodsDao dao  = null;
    String next   = null;
    String errmsg = null;
    HttpSession session = req.getSession(false);
    if (session == null || session.getAttribute("cust") == null) {
      errmsg = "ログインを行ってください。";
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    try {
      dao = new GoodsDao();
      dao.connect();
      ArrayList<Goods> list = dao.query();
      if (!list.isEmpty()) {
        req.setAttribute("list", list);
        next = "/goods/goods_list.jsp";
      } else {
        errmsg = "商品一覧の取得に失敗しました。";
        next   = "/system/error.jsp";
        req.setAttribute("errmsg", errmsg);
      }
    } catch (ClassNotFoundException | SQLException e) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
        } catch (SQLException e) {}
      }
    }
    // 画面遷移
    req.getRequestDispatcher(next).forward(req, res);
  }
}
