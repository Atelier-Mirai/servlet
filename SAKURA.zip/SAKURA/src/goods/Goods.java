package goods;
import util.StringUtility;

// 商品情報を保持します。
public record Goods(String cd,
                    String genre,
                    String name,
                    String notes,
                    String picturePath,
                    int    price) {
  public Goods {
    // compact constructor
  }

  // for jsp:useBean
  public String getCd()          { return cd; }
  public String getGenre()       { return genre; }
  public String getName()        { return name; }
  public String getNotes()       { return notes; }
  public String getPicturePath() { return picturePath; }
  public String getPrettyPrice() { return prettyPrice(); }

  public String prettyPrice() {
    return StringUtility.prettify(price);
  }

  public String toString() {
    return String.format("cd: %s, genre: %s, name: %s, price: %d\n", cd, genre, name, price);
  }
}
