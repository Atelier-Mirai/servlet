package customer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import dao.Dao;

// CUSTOMERS(顧客)テーブルにアクセスしデータを永続化・復元する。
public class CustomerDao extends Dao {
  public String create(Customer customer) throws SQLException {
    PreparedStatement stmt1 = null;
    PreparedStatement stmt2 = null;
    ResultSet rs            = null;
    try {
      // オートコミットモード無効
      con.setAutoCommit(false);
      // 顧客番号を作成するSQL作成
      String sql1 = "SELECT nextval('customer_no_seq') AS number";
      stmt1 = con.prepareStatement(sql1);
      // SQL実行
      rs = stmt1.executeQuery();
      // 初回登録時は1とする
      int number = 1;
      if (rs.next()) {
        number = rs.getInt("number");
      }
      // 規定桁数で0詰めし顧客IDを作成
      String customerId = String.format("%010d", number);
      // 顧客レコードを登録するSQL文作成
      String sql2 = "INSERT INTO customers VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
      // PreparedStatementのオブジェクト生成
      stmt2 = con.prepareStatement(sql2);
      // PreparedStatementの入力パラメータをセット
      stmt2.setString(1, customerId);
      stmt2.setString(2, customer.familyName());
      stmt2.setString(3, customer.givenName());
      stmt2.setString(4, customer.password());
      stmt2.setString(5, customer.postalCode());
      stmt2.setString(6, customer.address());
      stmt2.setString(7, customer.phone());
      stmt2.setString(8, customer.email());

      String str = stmt2.toString();

      // SQL文実行
      stmt2.executeUpdate();
      // コミット(確定)
      con.commit();
      // 採番された顧客IDを返す
      return customerId;
    } catch (SQLException e) {
      try {
        // ロールバック
        con.rollback();
      } catch (SQLException se) {
      }
      throw e;
    } finally {
      try {
        if (rs    != null) { rs.close(); }
        if (stmt1 != null) { stmt1.close(); }
        if (stmt2 != null) { stmt2.close(); }
      } catch (SQLException e) {}
    }
  }

  // ログイン認証を行う。
  public Customer certify(String id, String password) throws SQLException {
    Customer customer      = null;
    PreparedStatement stmt = null;
    ResultSet rs           = null;
    try {
      // 顧客データを検索するSQL作成
      String sql = """
                    SELECT
                    customer_no as id,
                    customer_name_last as family_name,
                    customer_name_first as given_name,
                    customer_password as password,
                    customer_postal_no as postal_code,
                    customer_address as address,
                    customer_phone as phone,
                    customer_email as email
                    FROM customers
                    WHERE customer_no = ? AND customer_password = ?
                   """;
      stmt = con.prepareStatement(sql);
      // PreparedStatementの入力パラメータをセットし、SQL実行する
      stmt.setString(1, id);
      stmt.setString(2, password);
      rs = stmt.executeQuery();

      if (rs.next()) {
        // 認証OKなら Customerオブジェクトを生成し、顧客データを設定
        customer = new Customer(rs.getString("id"),
                                rs.getString("family_name"),
                                rs.getString("given_name"),
                                rs.getString("password"),
                                rs.getString("postal_code"),
                                rs.getString("address"),
                                rs.getString("phone"),
                                rs.getString("email"));
      }
      return customer;
    } catch (SQLException e) {
      throw e;
    } finally {
      try {
        if (rs   != null) { rs.close(); }
        if (stmt != null) { stmt.close(); }
      } catch (SQLException e) {}
    }
  }
}
