package customer;

// 顧客情報を保持します。
public record Customer(String id,
                       String familyName,
                       String givenName,
                       String password,
                       String postalCode,
                       String address,
                       String phone,
                       String email) {
  public Customer {
    // compact constructor
  }

  // for jsp:useBean
  public String getFullName(){
    return familyName + " " + givenName;
  }

  // validation methods
  // 名前はまるまるで・・・
  // メールアドレスは・・・
}
