package customer;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.StringUtility;

// 顧客情報を登録
@WebServlet({"/customer/CustomerRegistServlet"})
public class CustomerRegistServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    CustomerDao dao = null;
    String next     = null;
    String errmsg   = "";
    req.setCharacterEncoding("UTF-8");

    // パラメタの取得
    String familyName = req.getParameter("family_name");
    String givenName  = req.getParameter("given_name");
    String password   = req.getParameter("password");
    String passwordConfirmation = req.getParameter("password_confirmation");
    String postalCode = req.getParameter("postal_code");
    String address    = req.getParameter("address");
    String phone      = req.getParameter("phone");
    String email      = req.getParameter("email");

    // 入力チェック
    if (StringUtility.isBlank(familyName) ||
        StringUtility.isBlank(givenName)) {
      errmsg += "姓・名は必須です。<br>";
    } else if (familyName.strip().length() >= 6 ||
               givenName.strip().length() >= 6) {
      errmsg += "姓・名は5文字以下です。<br>";
    }
    if (StringUtility.isBlank(password)) {
      errmsg += "パスワードは必須です。<br>";
    } else if (password.strip().length() < 4 ||
               password.strip().length() >= 11) {
      errmsg += "パスワードは4文字以上10文字以内です。<br>";
    } else if (!password.equals(passwordConfirmation)) {
      // パスワード整合性チェック
      errmsg += "不正なパスワードです。<br>";
    }
    if (StringUtility.isBlank(postalCode)) {
      errmsg += "郵便番号は必須です。<br>";
    } else if (postalCode.strip().length() != 7) {
      errmsg += "郵便番号の桁が違います。<br>";
    }
    if (StringUtility.isBlank(address)) {
      errmsg += "住所は必須です。<br>";
    } else if (address.strip().length() >= 26) {
      errmsg += "住所は25文字以内です。<br>";
    }
    if (StringUtility.isBlank(phone)) {
      errmsg += "電話番号は必須です。<br>";
    } else if (phone.strip().length() >= 12) {
      errmsg += "電話番号は11桁以内です。<br>";
    }
    if (StringUtility.isPresent(email) && email.strip().length() >= 21) {
      errmsg += "e-Mailは20文字以内です。<br>";
    }

    // 入力チェックにてエラーがあった場合(異常系)
    if (!errmsg.equals("")) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
    }

    // 正常系
    try {
      // Customerを生成、DBに登録する。
      var customer = new Customer("", // DB insert 時に自動採番
                                  familyName, givenName, password,
                                  postalCode, address, phone, email);

      dao = new CustomerDao();
      dao.connect();
      String customerId = dao.create(customer);
      req.setAttribute("customerId", customerId);
      next = "/customer/customer_accept.jsp";
    } catch (ClassNotFoundException | SQLException e) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
          // 例外に対しては何も処理を行わない
        } catch (SQLException e) {}
      }
    }
    req.getRequestDispatcher(next).forward(req, res);
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doPost(req, res);
  }
}
