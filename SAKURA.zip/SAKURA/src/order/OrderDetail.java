package order;

import goods.Goods;
import util.StringUtility;

// 注文明細情報(Goodsオブジェクト、注文数量)を保持する。
public class OrderDetail {
  private Goods goods;
  private int   quantity;

  public void setGoods(Goods goods) {
    this.goods = goods;
  }

  // 引数で受け取ったオブジェクトと、
  // 保持しているGoodsオブジェクトの商品コードを比較、真偽値を返す。
  public boolean equals(Object o) {
    var data = (OrderDetail) o;
    return this.getGoodsCd().equals(data.getGoodsCd());
  }

  // アクセッサー
  public String getGoodsCd()    { return goods.cd(); }
  public String getGoodsName()  { return goods.name(); }
  public int    getGoodsPrice() { return goods.price(); }
  public String getGoodsPrittyPrice() { return goods.prettyPrice(); }
  public int    getSubtotal()         { return goods.price() * quantity; }
  public String getPrittySubtotal() {
    return StringUtility.prettify(goods.price() * quantity);
  }
  public int    getQuantity()             { return quantity; }
  public void   setQuantity(int quantity) { this.quantity = quantity; }
}
