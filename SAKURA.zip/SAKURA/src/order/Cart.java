package order;

import java.util.ArrayList;
import util.StringUtility;

// 買い物かご
// 複数のOrderDetail(= Goods + 数量)オブジェクトを保持する。
public class Cart {
  private ArrayList<OrderDetail> orderDetailList = new ArrayList<>();

  public void addOrderDetail(OrderDetail orderDetail) {
    // 既存のorderDetailListに、追加する商品が存在するか調べる
    if (this.orderDetailList.contains(orderDetail)) {
      // 既に当該商品が追加済みの場合
      int index = this.orderDetailList.indexOf(orderDetail);
      var cartOrder = (OrderDetail) this.orderDetailList.get(index);

      // 数量をカウントアップ
      cartOrder.setQuantity(cartOrder.getQuantity() +
                            orderDetail.getQuantity());
    } else {
      // 新規商品を追加
      this.orderDetailList.add(orderDetail);
    }
  }

  // 買い物かごから商品を削除する
  public void deleteGoods(OrderDetail orderDetail) {
    this.orderDetailList.remove(orderDetail);
  }

  // 合計金額を返す
  public int getTotalAmount() {
    int total = 0;
    for (OrderDetail orderDetail: orderDetailList) {
      total += orderDetail.getSubtotal();
    }
    return total;
  }

  // 合計金額を返す
  public String getPrettyTotalAmount() {
    return StringUtility.prettify(getTotalAmount());
  }

  // 買い物かごから全ての注文明細を削除する
  public void clear() {
    this.orderDetailList.clear();
  }

  // 注文明細リストを取得する
  public ArrayList<OrderDetail> getOrderDetailList() {
    return orderDetailList;
  }
}
