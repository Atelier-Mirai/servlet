package order;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


// 買い物かごの表示を行うServlet
@WebServlet({"/order/ViewCartServlet"})
public class ViewCartServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doGet(req, res);
  }
  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    String next   = null;
    String errmsg = null;
    HttpSession session = req.getSession(false);
    if (session == null || session.getAttribute("cust") == null) {
      errmsg = "ログインを行ってください。";
      next   = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    // セッションからCartオブジェクトを取得
    var cart = (Cart) session.getAttribute("cart");
    if (cart == null) {
      cart = new Cart();
      session.setAttribute("cart", cart);
    }
    next = "/order/cart.jsp";
    // 画面遷移
    req.getRequestDispatcher(next).forward(req, res);
  }
}
