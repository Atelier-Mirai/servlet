package order;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.Dao;

// Ordersテーブルにアクセスしデータを永続化・復元する。
public class OrderDao extends Dao {
  // 注文処理を行います。
  // １．オートコミットを無効化する。
  // ２．order_no_seqシーケンステーブルから注文番号を取得、10桁で0詰する。
  // ３．ORDERSテーブルに注文情報を登録。(注文日はDBのシステム日付)
  // ４．ORDER_DETAILSテーブルに注文明細情報を登録。
  // ５．トランザクションをコミットし、注文番号を返す。
  public String create(Order order) throws SQLException {
    PreparedStatement stmt1 = null;
    PreparedStatement stmt2 = null;
    PreparedStatement stmt3 = null;
    ResultSet rs = null;
    try {
      // オートコミットモード無効
      con.setAutoCommit(false);
      String sql1 = "SELECT nextval('order_no_seq') AS order_no";
      stmt1 = con.prepareStatement(sql1);
      rs = stmt1.executeQuery();

      // 初回登録時は1とする
      int orderNo = 1;
      if (rs.next()) {
        orderNo = rs.getInt("order_no");
      }
      // 0詰めし、注文番号を作成
      String insOrderNo = String.format("%010d", orderNo);

      // ORDERSテーブルへ追加
      // 注文を追加するSQL文生成
      String sql2 = """
                      INSERT INTO orders
                      (order_no, customer_no, order_date, total_price)
                      VALUES(?, ?, current_date, ?)
                    """;
      stmt2 = con.prepareStatement(sql2);
      // 注文番号、顧客番号、購入小計をセット
      stmt2.setString(1, insOrderNo);
      stmt2.setString(2, order.getCustomer().id());
      stmt2.setInt(3, order.getTotalAmount());
      // SQLステートメントの実行
      stmt2.executeUpdate();

      // ORDER_DETAILSテーブルへ追加
      for (OrderDetail orderDetail: order.getOrderDetailList()) {
        // 注文明細情報を追加するSQL文生成
        String sql3 = "INSERT INTO order_details VALUES(?, ?, ?, ?)";
        // PreparedStatementのオブジェクト生成
        stmt3 = con.prepareStatement(sql3);
        // PreparedStatementの入力パラメータに,
        // 注文番号、商品コード、数量、単価をセット
        stmt3.setString(1, insOrderNo);
        stmt3.setString(2, orderDetail.getGoodsCd());
        stmt3.setInt(3, orderDetail.getQuantity());
        stmt3.setInt(4, orderDetail.getGoodsPrice());
        // SQLステートメントの実行
        stmt3.executeUpdate();
      }
      // コミット
      con.commit();
      // 注文番号を返す
      return insOrderNo;

    } catch (SQLException e) {
      try {
        // ロールバック
        con.rollback();
      } catch (SQLException se) {}
      throw e;
    } finally {
      try {
        if (rs != null) { rs.close(); }
        if (stmt1 != null) { stmt1.close(); }
        if (stmt2 != null) { stmt2.close(); }
        if (stmt3 != null) { stmt3.close(); }
      } catch (SQLException e) {}
    }
  }
}
