package order;

import java.util.ArrayList;
import customer.Customer;

// 注文情報(Customerと、複数のOrderDetail)を保持
public class Order {
  // 注文明細を格納するコレクション
  private ArrayList<OrderDetail> orderDetailList;
  private Customer customer;

  // 合計金額を返す
  public int getTotalAmount() {
    int total = 0;
    for (OrderDetail orderDetail: orderDetailList) {
      total += orderDetail.getSubtotal();
    }
    return total;
  }

  // ゲッター（注文明細リスト）
  public ArrayList<OrderDetail> getOrderDetailList() {
    return orderDetailList;
  }

  // セッター（注文明細リスト）
  public void setOrderDetailList(ArrayList<OrderDetail> orderDetailList) {
    this.orderDetailList = orderDetailList;
  }

  // ゲッター（顧客）
  public Customer getCustomer() {
    return customer;
  }

  // セッター（顧客）
  public void setCustomer(Customer customer) {
    this.customer = customer;
  }
}
