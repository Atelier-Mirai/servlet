package order;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import goods.Goods;
import util.StringUtility;

// 買い物かごから注文明細を削除する
@WebServlet({"/order/DeleteCartServlet"})
public class DeleteCartServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    req.setCharacterEncoding("UTF-8");
    String next         = null;
    String errmsg       = null;
    HttpSession session = req.getSession(false);
    if (session == null || session.getAttribute("cust") == null) {
      errmsg = "ログインを行ってください。";
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    // Cartオブジェクトを取得
    var cart    = (Cart)session.getAttribute("cart");
    // 削除する商品コードを取得
    var goodsCd = req.getParameter("submit");

    // validation
    if (StringUtility.isBlank(goodsCd)) {
      errmsg = "商品コードの取得に失敗しました。";
    } else {
      if (cart == null) {
        // 買い物かごのチェック
        errmsg = "不正なアクセスが行われました。";
      }
    }

    // 異常系
    if (errmsg != null) {
      req.setAttribute("errmsg", errmsg);
      next = "/system/error.jsp";
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    // 正常系
    // カートから選択した商品を削除する
    var goods = new Goods(goodsCd, "_dummy_genre",
                                   "_dummy_name",
                                   "_dummy_notes",
                                   "_dummy_picturePath",
                                   0); // _dummy_price
    var orderDetail = new OrderDetail();
    orderDetail.setGoods(goods);
    cart.deleteGoods(orderDetail);

    // 商品削除後のカートを、セッションに設定、cart.jspに遷移
    session.setAttribute("cart", cart);
    next = "/order/cart.jsp";
    req.getRequestDispatcher(next).forward(req, res);
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doPost(req, res);
  }
}
