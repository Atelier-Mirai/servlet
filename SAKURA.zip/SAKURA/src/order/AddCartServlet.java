package order;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import goods.Goods;
import goods.GoodsDao;
import util.StringUtility;

// 注文明細を買い物かごに追加する
@WebServlet({"/order/AddCartServlet"})
public class AddCartServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    req.setCharacterEncoding("UTF-8");
    GoodsDao dao        = null;
    String next         = null;
    String errmsg       = null;
    HttpSession session = req.getSession(false);

    if (session == null || session.getAttribute("cust") == null) {
      errmsg = "ログインを行ってください。";
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    // 商品コードと数量の取得
    String goodsCd        = req.getParameter("goodsCd");
    String quantityString = req.getParameter("quantity");
    int    quantity       = 0;
    if (StringUtility.isBlank(goodsCd)) {
      errmsg = "商品コードの取得に失敗しました。";
    } else if (StringUtility.isBlank(quantityString)) {
      errmsg = "数量は必須です。";
    } else {
      try {
        quantity = Integer.parseInt(quantityString);
      } catch (NumberFormatException e) {
        errmsg = "数量は整数です。";
      }
    }

    if (errmsg == null && quantity <= 0) {
      errmsg = "数量は1以上です。";
    } else if (errmsg == null && quantity >= 100) {
      errmsg = "一回に追加できる数量を超えています。";
    }

    if (errmsg != null) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    try {
      dao = new GoodsDao();
      dao.connect();
      Goods goods = dao.findByGoodsCd(goodsCd);
      if (goods == null) {
        errmsg = "商品情報の取得に失敗しました。";
        req.setAttribute("errmsg", errmsg);
        next = "/system/error.jsp";
        req.getRequestDispatcher(next).forward(req, res);
        return;
      }

      // セッションからCartオブジェクトを取得
      var cart = (Cart) session.getAttribute("cart");
      if (cart == null) {
        cart = new Cart();
      }

      var orderDetail = new OrderDetail();
      orderDetail.setGoods(goods);
      orderDetail.setQuantity(quantity);
      cart.addOrderDetail(orderDetail);

      session.setAttribute("cart", cart);
      next = "/order/cart.jsp";
    } catch (ClassNotFoundException | SQLException e) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
        } catch (SQLException e) {}
      }
    }
    // 画面遷移
    req.getRequestDispatcher(next).forward(req, res);
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doPost(req, res);
  }
}
