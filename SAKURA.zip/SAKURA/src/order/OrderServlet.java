package order;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import customer.Customer;

// 注文確定用Servlet
@WebServlet({"/order/OrderServlet"})
public class OrderServlet extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    req.setCharacterEncoding("UTF-8");
    OrderDao dao  = null;
    String next   = null;
    String errmsg = null;
    HttpSession session = req.getSession(false);

    if (session == null || session.getAttribute("cust") == null) {
      errmsg = "ログインを行ってください。";
      next   = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
      return;
    }

    // セッションからCartオブジェクトを取得
    var cart = (Cart) session.getAttribute("cart");
    // 買い物かごが空の場合はエラー画面にフォワード
    if (cart == null || cart.getOrderDetailList().isEmpty()) {
      errmsg = "注文する商品を選択してください。";
    }
    if (errmsg != null) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", errmsg);
      req.getRequestDispatcher(next).forward(req, res);
    }

    // 正常系
    try {
      dao = new OrderDao();
      dao.connect();
      Order order = new Order();

      // 顧客情報格納
      order.setCustomer((Customer) session.getAttribute("cust"));
      // CartオブジェクトからOrderオブジェクトへ注文明細を渡す
      order.setOrderDetailList(cart.getOrderDetailList());
      // ORDERSテーブル,ORDER_DETAILSテーブルに注文を登録
      String orderNo = dao.create(order);
      // Cartオブジェクトから全ての注文明細を削除
      cart.clear();
      // リクエストに情報追加
      req.setAttribute("orderNo", orderNo);
      // フォワード先を指定
      next = "/order/order_accept.jsp";

    } catch (ClassNotFoundException | SQLException e) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
          // 例外に対しては何も処理を行わない
        } catch (SQLException e) {}
      }
    }
    // 画面遷移
    req.getRequestDispatcher(next).forward(req, res);
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    this.doPost(req, res);
  }
}
