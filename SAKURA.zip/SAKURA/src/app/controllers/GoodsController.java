package app.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goods.Goods;
import goods.GoodsDao;

public class GoodsController extends Controller {

  // index
  public String index(HttpServletRequest req, HttpServletResponse res) throws Exception {
    req.setCharacterEncoding("UTF-8");
    var dao = new GoodsDao();
    dao.connect();
    ArrayList<Goods> list = dao.query();
    req.setAttribute("list", list);
    return "index";
  }

  // show
  public String show(HttpServletRequest req, HttpServletResponse res) throws Exception {
    // epath : "/0000000001"
    String epath = req.getPathInfo();
    // id : "0000000001"
    String id    = epath.substring(1);
    System.out.printf("id: %s\n", id);

    var dao = new GoodsDao();
    dao.connect();
    Goods goods = dao.findByGoodsCd(id);
    req.setAttribute("goods", goods);
    return "show";
  }
}
