package app.controllers;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import customer.Customer;
import customer.CustomerDao;
import util.StringUtility;

public class LogoutController extends Controller {
  // (DELETEだが、便宜上GETメソッド)
  // destroy
  public String destroy(HttpServletRequest req, HttpServletResponse res) throws Exception {
    System.out.printf("destroy\n");


    // セッションの取得
    HttpSession session = req.getSession(false);
    if (session == null || session.getAttribute("cust") == null) {
      req.setAttribute("errmsg", "ログインを行ってください。");
      return "/system/error.jsp";
    }

    // セッションの破棄
    session.invalidate();
    return "/login";
  }
}
