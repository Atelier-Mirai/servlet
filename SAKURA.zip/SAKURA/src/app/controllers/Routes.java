package app.controllers;

// それぞれのURLに応じて、
// それぞれのサーブレットが、
// それぞれの処理を行い、
// それぞれのjspに返すのって美しくないよね。
// フロントコントローラパターンで綺麗にしたいな〜

// ブラウザからのリクエストは一括して、
// フロントコントローラ(routes.rb)が受け取ります。
// フロントコントローラは、URLパターンから各コントローラのアクションを呼び出します。
// 各アクションは適宜処理を実行、戻り値として、jspファイル名を返します。
// フロントコントローラは、jspファイルにリクエストフォワード、結果を表示します。

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/login", "/logout", "/goods/*", "/search"})
public class Routes extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    res.setCharacterEncoding("UTF-8");
    PrintWriter out = res.getWriter();
    try {
      // パスを取得
      // REST 原則に従って、
      // 各コントローラから各ビューを表示させたい。

      // サーブレットパス
      String spath = req.getServletPath();
      System.out.printf("servlet path: %s\n", spath);
      // 拡張パス
      String epath = req.getPathInfo();
      System.out.printf("path info: %s\n", epath);
      // http method
      String httpMethod = req.getMethod();
      System.out.printf("http method: %s\n", httpMethod);

      // 趣味のメタプログラミング
      // /goods -> Goods
      String klassName = spath.substring(1, 2).toUpperCase() + spath.substring(2);

      // クラスの取得
      // app.contollers.GoodsController
      Class<?> klass = Class.forName("app.controllers." + klassName + "Controller");

      // インスタンスの取得
      Object obj = klass.getDeclaredConstructor().newInstance();
      // メソッドの取得
      // Method show = klass.getMethod("show", String.class);
      // Method index = klass.getMethod("index", HttpServletRequest.class, HttpServletResponse.class);
      // メソッドの実行
      // show.invoke(obj, "show method invoke");


      // 拡張パスによって、呼ぶメソッドを変更する
      // (実質 goods, goods/:id のための処理)
      if (epath == null) { epath = "/"; }
      String methodName = switch(epath) {
                            case "/" -> "index";
                            default  -> "show";
                          };

      // login, logout, search のための処理
      switch(klassName) {
        case "Login" -> {
          methodName = switch(httpMethod) {
                                case "GET" -> "neww"; // new is reserved by java.
                                case "POST" -> "create";
                                default  -> "create";
                              };
          }
        case "Logout" -> {
          methodName = "destroy";
        }
        case "Search" -> {
          if (httpMethod.equals("POST")){
            methodName = "index";
          } else if (httpMethod.equals("GET")){
            methodName = "neww";
          }
        }
      }

      // クラス名、メソッド名確認
      System.out.printf("%s#%s\n", klassName, methodName);

      // メソッドの実行
      String next = (String)klass.getMethod(methodName, HttpServletRequest.class, HttpServletResponse.class).invoke(obj, req, res);

      // 表示するビューの指定
      String url = "";
      if (next.equals("error")) {
        url = "/system/error.jsp";
      } else {
        // next = "/views/goods/index.jsp";
        url = "/views/" + klassName.toLowerCase() +
                      "/" + next + ".jsp";
      }
      // login, logout なら、
      // 戻り値の文字列を、そのままリクエストディスパッチャへ渡す。
      if (klassName.equals("Login") && methodName.equals("create") ||
          klassName.equals("Logout")) {
        url = next;
      }



      // リクエスト・ディスパッチャ
      req.getRequestDispatcher(url).forward(req, res);
    } catch (java.lang.reflect.InvocationTargetException e) {
      System.out.println(e.getCause());
      e.printStackTrace(out);
    } catch (Exception e) {
      System.out.println(e.getCause());
      e.printStackTrace(out);
    }
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res)
  throws ServletException, IOException {
    doPost(req, res);
  }
}
