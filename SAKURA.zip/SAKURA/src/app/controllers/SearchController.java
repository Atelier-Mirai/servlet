package app.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.SQLException;
import java.util.ArrayList;

import util.StringUtility;

import goods.Goods;
import goods.GoodsDao;

public class SearchController extends Controller {

  // index 検索結果をセット、一覧表示画面へ遷移
  public String index(HttpServletRequest req, HttpServletResponse res) throws Exception {
    req.setCharacterEncoding("UTF-8");
    GoodsDao dao  = null;
    String next   = null;
    String errmsg = null;

    // ユーザ入力値取得
    String genre       = req.getParameter("genre");
    String name        = req.getParameter("name");
    String priceString = req.getParameter("price");

    // validation
    if (StringUtility.isPresent(genre) &&
          !(genre.equals("flower") ||
           genre.equals("liquor") ||
           genre.equals("food"))) {
      errmsg += "不正な商品分類です。<br>";
    }
    if (StringUtility.isPresent(name) && name.strip().length() >= 21) {
      errmsg += "商品名は20文字以下です。<br>";
    }
    int price = 0;
    if (StringUtility.isPresent(priceString)) {
      try {
        price = Integer.parseInt(priceString);
        if (price <= 0) {
          errmsg += "不正な金額です。<br>";
        } else if (price >= 1_000_000) {
          errmsg += "指定できる金額は999999までです。<br>";
        }
      } catch (NumberFormatException e) {
        errmsg += "金額は整数です。";
      }
    }

    if (errmsg != null) {
      next = "error";
      req.setAttribute("errmsg", errmsg);
      return next;
    }

    try {
      var category = switch (genre) {
        case "flower" -> "花";
        case "liquor" -> "酒";
        case "food"   -> "食料品";
        default -> "";
      };
      dao = new GoodsDao();
      dao.connect();
      ArrayList<Goods> list = dao.queryByCondition(category, name, price==0 ? "" : String.valueOf(price));
      req.setAttribute("list", list);
      next = "index";
    } catch (ClassNotFoundException | SQLException e) {
      next = "error";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
        } catch (SQLException e) {}
      }
      return next;
    }
  }

  // neww 検索条件入力画面を表示
  public String neww(HttpServletRequest req, HttpServletResponse res) throws Exception {
    req.setCharacterEncoding("UTF-8");
    return "neww";
  }
}
