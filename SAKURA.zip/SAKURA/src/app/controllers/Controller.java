package app.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// 各アクションの親クラス
public class Controller {
  // ログインしてね〜
  // してなかったらerror.jsp表示するよ〜
  // (略)

  // 各メソッド（アクション）は、適宜、サブクラスで実装する。
  // （実質、抽象クラス）
  // 戻り値は、リクエスト・ディスパッチャしたいパスの文字列
  public String index(HttpServletRequest req, HttpServletResponse res) throws Exception { return ""; }
  public String show(HttpServletRequest req, HttpServletResponse res) throws Exception { return ""; }
  public String neww(HttpServletRequest req, HttpServletResponse res) throws Exception { return ""; }
  public String create(HttpServletRequest req, HttpServletResponse res) throws Exception { return ""; }
  public String edit(HttpServletRequest req, HttpServletResponse res) throws Exception { return ""; }
  public String update(HttpServletRequest req, HttpServletResponse res) throws Exception { return ""; }
  public String destroy(HttpServletRequest req, HttpServletResponse res) throws Exception { return ""; }
}
