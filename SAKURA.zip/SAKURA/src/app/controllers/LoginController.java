package app.controllers;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import customer.Customer;
import customer.CustomerDao;
import util.StringUtility;

public class LoginController extends Controller {
  // GET
  // new
  public String neww(HttpServletRequest req, HttpServletResponse res) throws Exception {
    // render "new"
    return "neww"; // new is reserved by java.
  }

  // POST
  // create
  public String create(HttpServletRequest req, HttpServletResponse res) throws Exception {
    String next     = null;
    String errmsg   = null;
    CustomerDao dao  = null;

    System.out.printf("create\n");
    try {
      req.setCharacterEncoding("UTF-8");
      var customerNumber = req.getParameter("number");
      var password       = req.getParameter("password");

      // Validation
      if (StringUtility.isBlank(customerNumber)) {
        errmsg += "顧客番号は必須です。<br>";
      }
      if (StringUtility.isBlank(password)) {
        errmsg += "パスワードは必須です。<br>";
      }

      // 異常系
      if (errmsg != null) {
        next = "/system/error.jsp";
        req.setAttribute("errmsg", errmsg);
        req.getRequestDispatcher(next).forward(req, res);
        return next;
      }

      // 正常系
      dao = new CustomerDao();
      dao.connect();
      // 認証
      Customer customer = dao.certify(customerNumber, password);
      if (customer != null) {
        // 認証成功ならセッションの生成
        HttpSession session = req.getSession(true);
        session.setAttribute("cust", customer);
        next = "/system/home.jsp";
      } else {
        // 認証失敗
        errmsg = "顧客番号またはパスワードに誤りがあります。再度ログインしてください。";
        req.setAttribute("errmsg", errmsg);
        next = "/system/error.jsp";
      }
    } catch (ClassNotFoundException | SQLException e ) {
      next = "/system/error.jsp";
      req.setAttribute("errmsg", e.getMessage());
      e.printStackTrace();
    } finally {
      if (dao != null) {
        try {
          dao.close();
        } catch (SQLException e) {}
      }
      return next;
    }
  }
}
