package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Dao {
  protected static final String DRIVER   = "org.postgresql.Driver";
  protected static final String URL      = "jdbc:postgresql://localhost:5432/sakura";
  protected static final String USER     = "sakura";
  protected static final String PASSWORD = "sakura";
  protected Connection con               = null;

  // JDBC Driverを登録し、データベースに接続します。
  // 発生してcatchした例外は、そのまま呼び出しもとにthrowします。
  public void connect() throws ClassNotFoundException, SQLException {
    try {
      // JDBC Driverの登録
      Class.forName(DRIVER);
      // DBへ接続
      con = DriverManager.getConnection(URL, USER, PASSWORD);
    } catch (ClassNotFoundException | SQLException e) {
      throw e;
    }
  }

  // データベースから切断します。
  // 発生してcatchした例外は、そのまま呼び出しもとにthrowします。
  public void close() throws SQLException {
    try {
      if (con != null && !con.isClosed()) { con.close(); }
    } catch (SQLException e) {
      throw e;
    }
  }
}
