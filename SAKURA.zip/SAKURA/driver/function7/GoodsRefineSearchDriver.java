package function7;

import java.sql.SQLException;
import java.util.ArrayList;

import goods.Goods;
import goods.GoodsDao;
import goods.GoodsQueryCondition;

// 条件検索のテストドライバです
// (CustomerDao、GoodsQueryConditionが必要です)
public class GoodsRefineSearchDriver {
  public static void main(String args[]) {
    GoodsDao dao = null;
    try {
      System.out.println("【function7】条件検索の単体テストを開始します。");
      // GoodsDaoの生成
      dao = new GoodsDao();
      // データベースに接続
      dao.connect();
      // ### case1 検索条件を設定(分類="食料品"→20件存在)
      GoodsQueryCondition condition1 = new GoodsQueryCondition();
      condition1.setCategory("食料品");
      condition1.setPrice(0);
      // 商品の条件検索結果取得
      ArrayList<Goods> list1 = dao.queryByCondition(condition1);
      int list1size = list1.size();
      if (list1size == 20) {
        System.out.println("\t**SUCCESS**");
      } else {
        System.out.println("\t**FAIL**商品の検索に失敗しました。");
      }
      // ### case2 商品名検索条件(分類="食料品"、名前="たまね"→1件)
      GoodsQueryCondition condition2 = new GoodsQueryCondition();
      condition2.setCategory("食料品");
      condition2.setName("たまね");
      condition2.setPrice(0);
      // 商品の条件検索結果取得
      ArrayList<Goods> list2 = dao.queryByCondition(condition2);
      int list2size = list2.size();
      if (list2size == 1) {
        System.out.println("\t**SUCCESS**");
      } else {
        System.out.println("\t**FAIL**商品の検索に失敗しました。");
      }
      // ### case3 商品単価検索条件(分類="食料品"、名前="たまね"、 \200以内→0件)
      GoodsQueryCondition condition3 = new GoodsQueryCondition();
      condition3.setCategory("食料品");
      condition3.setName("たまね");
      condition3.setPrice(200);
      // 商品の条件検索結果取得
      ArrayList<Goods> list3 = dao.queryByCondition(condition3);
      int list3size = list3.size();
      if (list3size == 0) {
        System.out.println("\t**SUCCESS**");
      } else {
        System.out.println("\t**FAIL**商品の検索に失敗しました。");
      }
      // ### case4 商品単価検索条件(分類="食料品"、名前="た"→0件)
      GoodsQueryCondition condition4 = new GoodsQueryCondition();
      condition4.setCategory("食料品");
      condition4.setName("た");
      condition4.setPrice(0);
      // 商品の条件検索結果取得
      ArrayList<Goods> list4 = dao.queryByCondition(condition4);
      int list4size = list4.size();
      if (list4size == 2) {
        System.out.println("\t**SUCCESS**");
      } else {
        System.out.println("\t**FAIL**商品の検索に失敗しました。");
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        dao.close();
      } catch (SQLException e) {}
    }
  }
}
