package function4;

import java.sql.SQLException;
import goods.Goods;
import goods.GoodsDao;

// 商品商品情報取得(一件)のテストドライバです。
public class GoodsViewDriver {
  public static void main(String[] args) {
    GoodsDao dao = null;
    try {
      // DB接続
      dao = new GoodsDao();
      dao.connect();
      System.out.println("【function4】商品詳細表示の単体テストを開始します。");
      // 一件分の商品情報取得
      Goods goods = dao.findByGoodsCd("0000000001");
      // ### case1
      if (goods == null) {
        System.out.println("\t**FAIL**商品情報取得(一件)が正しく行われていません。");
      } else {
        System.out.println("\t**SUCCESS**");
        // ### case2 商品情報は正しいものであるか
        if (goods.getCd().equals("0000000001")) {
          System.out.println("\t**SUCCESS**");
        } else {
          System.out.println("\t**FAIL**取得されたデータが正しくありません。");
        }
      }
      // 一件分の商品情報取得(存在しないコードを指定)
      Goods nogoods = dao.findByGoodsCd("9999999999");
      // ### case3
      if (nogoods != null) {
        System.out.println("\t**FAIL**商品が存在しない場合の処理が正しくありません。");
      } else {
        System.out.println("\t**SUCCESS**");
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        dao.close();
      } catch (SQLException e) {}
    }
  }
}
