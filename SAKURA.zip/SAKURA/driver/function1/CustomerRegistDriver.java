package function1;

import java.sql.SQLException;
import customer.Customer;
import customer.CustomerDao;

// 顧客登録のテストドライバです。
// (CustomerDao、Customerが必要です)
public class CustomerRegistDriver {
  public static void main(String[] args) {
    CustomerDao dao = null;
    try {
      // DB接続
      dao = new CustomerDao();
      dao.connect();
      // 顧客情報作成
      Customer cust = new Customer();
      cust.setNameLast("last");
      cust.setNameFirst("first");
      cust.setPassword("password");
      cust.setPostalNo("postnum");
      cust.setAddress("address");
      cust.setPhone("phone");
      cust.setEmail("email");
      // 顧客登録
      String cd = dao.create(cust);
      System.out.println("【function1】顧客登録の単体テストを開始します。");
      // ### case1
      if (cd == null || cd.equals("") || cd.trim().length() != 10) {
        System.out.println("\t**FAIL**正しい顧客コードが返されませんでした。");
      } else {
        System.out.println("\t**SUCCESS**");
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        dao.close();
      } catch (SQLException e) {}
    }
  }
}
