package function5;

import java.sql.SQLException;
import goods.Goods;
import goods.GoodsDao;
import order.Cart;
import order.OrderDetail;

// 買い物かごのテストドライバです。
// (CustomerDao、Goods、Cart、OrderDetailが必要です)
public class CartDriver {
  public static void main(String[] args) {
    GoodsDao dao = null;
    try {
      // DB接続
      dao = new GoodsDao();
      dao.connect();
      Goods goods1 = dao.findByGoodsCd("0000000001");
      Goods goods2 = dao.findByGoodsCd("0000000002");
      Goods goods3 = dao.findByGoodsCd("0000000003");
      System.out.println("【function5】買い物かごの単体テストを開始します。");
      // ### case1 商品追加チェック
      Cart cart = new Cart();
      // 0000000001を1個 追加
      OrderDetail orderDetail1 = new OrderDetail();
      orderDetail1.setGoods(goods1);
      orderDetail1.setQuantity(1);
      cart.addOrderDetail(orderDetail1);
      // 0000000002を2個 追加
      OrderDetail orderDetail2 = new OrderDetail();
      orderDetail2.setGoods(goods2);
      orderDetail2.setQuantity(2);
      cart.addOrderDetail(orderDetail2);
      // チェック
      OrderDetail orderCheck1 = (OrderDetail) cart.getOrderDetailList().get(0);
      OrderDetail orderCheck2 = (OrderDetail) cart.getOrderDetailList().get(1);
      if (orderCheck1.getGoodsCd().equals("0000000001") && orderCheck1.getQuantity() == 1 && orderCheck2.getGoodsCd().equals("0000000002") && orderCheck2.getQuantity() == 2) {
        System.out.println("\t**SUCCESS**");
      } else {
        System.out.println("\t**FAIL**商品の格納に失敗しました。");
      }
      // ### case2 同一商品追加チェック
      // 0000000003を1個 追加
      OrderDetail orderDetail3 = new OrderDetail();
      orderDetail3.setGoods(goods3);
      orderDetail3.setQuantity(1);
      cart.addOrderDetail(orderDetail3);
      // 0000000003を2個 追加
      OrderDetail orderDetail4 = new OrderDetail();
      orderDetail4.setGoods(goods3);
      orderDetail4.setQuantity(2);
      cart.addOrderDetail(orderDetail4);
      // チェック
      OrderDetail orderCheck3 = (OrderDetail) cart.getOrderDetailList().get(2);
      if (orderCheck3.getGoodsCd().equals("0000000003") && orderCheck3.getQuantity() == 3) {
        System.out.println("\t**SUCCESS**");
      } else {
        System.out.println("\t**FAIL**同一商品の格納に失敗しました。");
      }
      // ### case4 商品削除チェック
      cart.deleteGoods(orderDetail3);
      if (cart.getOrderDetailList().size() == 2) {
        System.out.println("\t**SUCCESS**");
      } else {
        System.out.println("\t**FAIL**商品の削除に失敗しました。");
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        dao.close();
      } catch (SQLException e) {}
    }
  }
}
