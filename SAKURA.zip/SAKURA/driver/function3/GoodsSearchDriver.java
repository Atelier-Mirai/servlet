package function3;

import java.sql.SQLException;
import java.util.ArrayList;
import goods.Goods;
import goods.GoodsDao;

// 商品一覧取得のテストドライバです。
// (CustomerDao、Goodsが必要です)
public class GoodsSearchDriver {
  public static void main(String[] args) {
    GoodsDao dao = null;
    try {
      // DB接続
      dao = new GoodsDao();
      dao.connect();
      // 商品一覧を取得します。
      ArrayList<Goods> list = dao.query();
      System.out.println("【function3】商品一覧表示の単体テストを開始します。");
      // ### case1
      if (list == null) {
        System.out.println("\t**FAIL**商品一覧取得が正しく行われていません。");
      } else {
        System.out.println("\t**SUCCESS**");
        Goods goods1 = (Goods) list.get(0);
        Goods goods2 = (Goods) list.get(1);
        // ### case2
        if (goods1.getCd().equals(goods2.getCd())) {
          System.out.println("\t**FAIL**取得されたデータが正しくありません。");
        } else {
          System.out.println("\t**SUCCESS**");
        }
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        dao.close();
      } catch (SQLException e) {}
    }
  }
}
