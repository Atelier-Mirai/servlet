package function2;

import java.sql.SQLException;
import customer.Customer;
import customer.CustomerDao;

// ログインのテストドライバです。
// (CustomerDao、Customerが必要です)
public class LoginDriver {
  public static void main(String[] args) {
    CustomerDao dao = null;
    try {
      // DB接続
      dao = new CustomerDao();
      dao.connect();
      // 顧客情報作成(パスワード=passwordで作成)
      Customer cust = new Customer();
      cust.setNameLast("last");
      cust.setNameFirst("first");
      cust.setPassword("password");
      cust.setPostalNo("1235678");
      cust.setAddress("address");
      cust.setPhone("123456789012");
      cust.setEmail("email");
      // 顧客登録
      String cd = dao.create(cust);
      Customer dbcust1 = dao.certify(cd, "password");
      Customer dbcust2 = dao.certify(cd, "ngpassword");
      System.out.println("【function2】ログインの単体テストを開始します。");
      // ### case1
      if (dbcust1 == null || dbcust2 != null) {
        System.out.println("\t**FAIL**認証が正しく行われていません。");
      } else {
        System.out.println("\t**SUCCESS**");
      }
      // ### case2
      if (!dbcust1.getNameLast().equals("last") || !dbcust1.getNameFirst().equals("first") || !dbcust1.getPassword().equals("password") || !dbcust1.getPostalNo().equals("1235678") || !dbcust1.getAddress().equals("address") || !dbcust1.getPhone().equals("123456789012") || !dbcust1.getEmail().equals("email")) {
        System.out.println("\t**FAIL**復元されたデータが不正です。");
      } else {
        System.out.println("\t**SUCCESS**");
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        dao.close();
      } catch (SQLException e) {}
    }
  }
}
