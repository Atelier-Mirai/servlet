package function6;

import java.sql.SQLException;
import java.util.ArrayList;
import customer.Customer;
import goods.Goods;
import goods.GoodsDao;
import order.Order;
import order.OrderDao;
import order.OrderDetail;

// 注文登録のテストドライバです。
// (CustomerDao，Goods，Cart，OrderDetail, Orderが必要です)
public class OrderDriver {
  public static void main(String args[]) {
    GoodsDao goodsdao = null;
    OrderDao orderdao = null;
    try {
      // 顧客情報作成
      Customer cust = new Customer();
      cust.setNameLast("last");
      cust.setNameFirst("first");
      cust.setPassword("password");
      cust.setPostalNo("postnum");
      cust.setAddress("address");
      cust.setPhone("phone");
      cust.setEmail("email");
      cust.setNo("0000000001");
      // 商品情報作成
      goodsdao = new GoodsDao();
      goodsdao.connect();
      Goods goods1 = goodsdao.findByGoodsCd("0000000001");
      Goods goods2 = goodsdao.findByGoodsCd("0000000002");
      // 注文明細作成
      OrderDetail orderDetail1 = new OrderDetail();
      orderDetail1.setGoods(goods1);
      orderDetail1.setQuantity(1);
      OrderDetail orderDetail2 = new OrderDetail();
      orderDetail2.setGoods(goods2);
      orderDetail2.setQuantity(10);
      // 注文明細の一覧作成
      ArrayList < OrderDetail > orderDetailList = new ArrayList < OrderDetail > ();
      orderDetailList.add(orderDetail1);
      orderDetailList.add(orderDetail2);
      // 注文作成
      Order order = new Order();
      order.setCustomer(cust);
      order.setOrderDetailList(orderDetailList);
      System.out.println("【function6】注文の単体テストを開始します。");
      // DB接続
      orderdao = new OrderDao();
      orderdao.connect();
      // ### case1
      String orderNo = orderdao.create(order);
      if (orderNo == null || orderNo.equals("") || orderNo.trim().length() != 10) {
        System.out.println("\t**FAIL**注文登録に失敗しました。");
      } else {
        System.out.println("\t**SUCCESS**");
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException se) {
      se.printStackTrace();
    } finally {
      try {
        goodsdao.close();
        orderdao.close();
      } catch (SQLException e) {}
    }
  }
}
