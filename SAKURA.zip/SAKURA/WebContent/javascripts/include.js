/*=====================================================================
  部分ファイルを読み込むための include 関数

  [使い方]
  <footer id="footer"></nav>
  <script>include("footer")</script>
  footerタグを、_footer.html に置換する。

  [参考]
  HTMLで簡単インクルード！ https://jp-seemore.com/web/2408/
=====================================================================*/
const include = (partial, text = "") => {
  let filename = `/SAKURA/shared/_${partial}.html`
  let id       = partial

  fetch(filename)
      .then(response => response.text())
      .then((data) => {
        if (text !== "") {
          // <title>タグ更新
          document.title = `${text}【さくらマーケット】`
          // <h2>タグ更新
          re = /<h2>(.*)<\/h2>/
          data = data.replace(re, `<h2>${text}</h2>`)
          // メニュー更新 selectedクラス付与
          hash = { "ホーム":     'id="home"',
                   "商品一覧":   'id="list"',
                   "商品詳細":   'id="list"',
                   "商品検索":   'id="search"',
                   "買い物かご": 'id="cart"',
                   "注文詳細":   'id="cart"',
                   "注文完了":   'id="cart"' }
          if (text in hash) {
            data = data.replace(hash[text], `${hash[text]} class="selected"`)
          }
          document.getElementById(id).outerHTML = data
        } else {
          document.getElementById(id).outerHTML = data
        }
      })
}
